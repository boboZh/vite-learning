<template>
  <div>Hello Vite Vue2</div>
</template>

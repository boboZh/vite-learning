import { defineComponent } from "vue";

export default defineComponent({
  setup() {
    return () => {
      return <div>Hello Vue3 Jsx</div>;
    };
  },
});

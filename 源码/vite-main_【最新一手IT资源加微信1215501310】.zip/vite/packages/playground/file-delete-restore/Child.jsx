export default function Child() {
  return <p>Child state 1</p>
}

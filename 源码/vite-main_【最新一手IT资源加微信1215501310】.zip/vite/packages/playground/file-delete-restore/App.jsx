import { useState } from 'react'
import Child from './Child'

function App() {
  return (
    <div className="App">
      <Child />
    </div>
  )
}

export default App

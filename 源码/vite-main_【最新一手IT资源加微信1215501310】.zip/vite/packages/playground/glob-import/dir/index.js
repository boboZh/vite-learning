const modules = import.meta.globEager('./*.js')

export { modules }

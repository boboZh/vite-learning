const modules = import.meta.globEager('../*.json')

export const msg = 'bar'
export { modules }

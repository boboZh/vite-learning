export const msg = '[success] linked force include'

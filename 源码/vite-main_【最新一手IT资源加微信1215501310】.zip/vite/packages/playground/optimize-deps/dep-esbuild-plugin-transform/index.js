// will be replaced by an esbuild plugin

export const hello = () => `Hello from a package`

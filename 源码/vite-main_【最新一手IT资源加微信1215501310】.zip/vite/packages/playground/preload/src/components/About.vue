<template>
  <div>
    This is <b>about</b> page.
    <br>
    Go to <router-link to="/">Home</router-link> page
  </div>
</template>

<script setup>
</script>

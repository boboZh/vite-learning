<template>
  <div>
    This is <b>home</b> page.
    <br>
    Go to <router-link to="/about">About</router-link> page
  </div>
</template>

<script setup>
</script>

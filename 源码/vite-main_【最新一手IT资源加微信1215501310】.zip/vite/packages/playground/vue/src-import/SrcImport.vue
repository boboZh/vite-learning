<template src="./template.html"></template>
<script src="./script.ts"></script>
<style src="/@/src-import/style.css" scoped></style>

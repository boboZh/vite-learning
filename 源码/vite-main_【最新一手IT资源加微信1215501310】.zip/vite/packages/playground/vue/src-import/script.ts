import { defineComponent } from 'vue'

export default defineComponent({
  setup() {
    return {
      msg: 'hello from script src!'
    }
  }
})

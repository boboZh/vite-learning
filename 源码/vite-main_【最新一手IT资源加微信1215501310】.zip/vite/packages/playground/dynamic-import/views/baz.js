import { n } from '../nested/shared'
console.log('baz' + n)

export const msg = 'Baz view'

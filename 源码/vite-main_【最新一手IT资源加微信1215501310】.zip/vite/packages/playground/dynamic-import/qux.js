export const msg = 'Qux view'

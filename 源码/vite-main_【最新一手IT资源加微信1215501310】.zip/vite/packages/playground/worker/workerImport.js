export const msg = 'pong'
export const mode = process.env.NODE_ENV

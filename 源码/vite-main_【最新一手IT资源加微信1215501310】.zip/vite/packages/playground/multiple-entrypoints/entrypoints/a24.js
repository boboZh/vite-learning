export const that = () => import('./a23.js')

export function other() {
  return
}

export default function () {
  return 123
}

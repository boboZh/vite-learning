import './reference.scss'

document.querySelector('.content').textContent = 'Reference'

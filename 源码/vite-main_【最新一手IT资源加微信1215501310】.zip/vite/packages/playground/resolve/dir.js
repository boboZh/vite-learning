export const file = '[success] dir.js'

export const file = '[success] ./dir-with-ext/index.js'

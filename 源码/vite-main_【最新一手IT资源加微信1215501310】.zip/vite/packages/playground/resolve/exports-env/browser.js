export const msg = 'fail (browser.js)'

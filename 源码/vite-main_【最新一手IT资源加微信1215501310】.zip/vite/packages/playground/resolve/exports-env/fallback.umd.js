export const msg = 'fail (fallback.umd.js)'

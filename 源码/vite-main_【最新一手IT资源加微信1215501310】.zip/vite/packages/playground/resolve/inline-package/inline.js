export const msg = '[success] from inline package'

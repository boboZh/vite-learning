export const msg = '[success] deep resolve from exports'

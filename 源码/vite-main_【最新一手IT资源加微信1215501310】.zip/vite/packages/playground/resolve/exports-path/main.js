export const msg = '[success] entry resolve from exports'

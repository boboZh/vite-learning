const fs = require('fs')
console.log('this should not run in the browser')

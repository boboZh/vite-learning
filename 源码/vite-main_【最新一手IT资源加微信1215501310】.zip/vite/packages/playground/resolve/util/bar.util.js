export function bar() {
  return '[success] resolve filename containing dot and omitting ext'
}

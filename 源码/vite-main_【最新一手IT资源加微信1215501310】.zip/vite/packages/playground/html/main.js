import { msg } from './shared'
import './common.css'

console.log(msg + ' from main')

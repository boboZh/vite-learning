export const msg = `[success] alias to directory`

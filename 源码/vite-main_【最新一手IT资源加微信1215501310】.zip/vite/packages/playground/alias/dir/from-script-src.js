document.querySelector('.from-script-src').textContent =
  '[success] from script src'

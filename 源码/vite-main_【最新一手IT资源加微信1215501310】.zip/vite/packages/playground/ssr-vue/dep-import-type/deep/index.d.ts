export interface Foo {}

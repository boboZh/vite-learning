import './style.css'
import './main.css'

document.getElementById(
  'app'
).innerHTML = `<h1>This should be red</h1><h2>This should be blue</h2>`

import { msg as depMsg } from '../dep'

export const msg = `[success] out of root monorepo dep with ${depMsg}`
